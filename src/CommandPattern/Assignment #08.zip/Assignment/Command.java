package CommandPattern.Assignment;

public interface Command {
    public void execute();
}
