public class Shape {
    int X,Y;
    public Shape(int X,int Y){
        this.X=X;
        this.Y=Y;
    }
    public int CalcArea(){
        return this.X*this.Y;
    }
}
