package DecoratorPattern;

public class Mocha extends CondimentalDecorator{
    Beverage beverage;
    public Mocha(Beverage beverage){
        this.beverage = beverage;
    }
    public String getDescription(){
        return beverage.getDescription() + "모카";
    }
    public double cost(){
        return beverage.cost() +.20;
    }
}
