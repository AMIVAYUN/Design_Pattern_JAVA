package DecoratorPattern;

public abstract class CondimentalDecorator extends Beverage{
    public abstract String getDescription();
}
