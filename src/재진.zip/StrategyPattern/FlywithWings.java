package StrategyPattern;
public class FlywithWings implements Fly{
    @Override
    public void fly(){
        System.out.println("Fly with wings");
    }
}
