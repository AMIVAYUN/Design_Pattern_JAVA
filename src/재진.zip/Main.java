import java.util.ArrayList;

public class Main {
    public static void main(String[] args){
        //TODO 예제1
        /*
        ShapeTag s1=new ShapeTag("shape1");
        ShapeTag s2=new ShapeTag("shape2");
        RectangleTag r=new RectangleTag("shape","rectangle");
        CircleTag c = new CircleTag("shape","circle");
        System.out.println("Shape1 Tag: "+s1);
        System.out.println("Shape2 Tag: "+s2);
        System.out.println("RectangleTag: "+r);
        System.out.println("CircleTag: "+c);
        // 다형성
        s1=r;
        s2=c;
        System.out.println("this is polymorphism");
        System.out.println("RectangleTag: "+s1);
        System.out.println("CircleTag: "+s2);
        ArrayList list = new ArrayList();
        list.add(new ShapeTag("shape1"));
        list.add(new ShapeTag("shape2"));
        list.add(new RectangleTag("shape", "rectangle"));
        list.add(new CircleTag("shape", "circle"));
        for (Object o : list) {
            System.out.println(o);
            System.out.println(((ShapeTag) o).toString());
        }

         */
        //TODO 예제2
        /*
        ArrayList<Shape>shapes=new ArrayList<Shape>();
        shapes.add(new Rectangle("rect",3,4));
        shapes.add(new Circle("circ",3,3));
        for(Shape shape:shapes){
            System.out.println(shape.CalcArea());
        }

         */


    }
}
