package ObserverPattern;

public interface Observer {
    public void update(int temp,int humidity,int pressure);
}
