package StatePattern.Assignment;

public interface State {
    public void processNumber(String ch);


    public void processOperator(char ch);
}
